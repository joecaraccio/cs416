package src;

/**
 * Created by Joe on 2/3/2016.
 */
public interface NewFrame {
    void newFrame();
}
