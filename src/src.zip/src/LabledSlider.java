package src;

/**
 * Created by Joe on 2/3/2016.
 */
public class LabledSlider {
}
