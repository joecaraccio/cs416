package src;

/**
 * Created by Joe on 2/3/2016.
 */
public interface Animated extends NewFrame {
    void setAnimated(boolean var1);

    boolean isAnimated();
}
