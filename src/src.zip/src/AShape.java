package src;

/**
 * Created by Joe on 2/3/2016.
 */
import java.awt.Graphics2D;

public interface AShape {
    void display(Graphics2D var1);
}
